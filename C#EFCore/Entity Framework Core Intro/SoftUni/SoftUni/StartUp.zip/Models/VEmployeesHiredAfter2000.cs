﻿using System;
using System.Collections.Generic;

namespace SoftUni.Models
{
    public partial class VEmployeesHiredAfter2000
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
