﻿using System;
using System.Collections.Generic;

namespace SoftUni.Models
{
    public partial class VEmployeeNameJobTitle
    {
        public string FullName { get; set; }
        public string JobTitle { get; set; }
    }
}
