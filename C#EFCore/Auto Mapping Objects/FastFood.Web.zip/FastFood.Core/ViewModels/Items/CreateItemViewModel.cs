﻿namespace FastFood.Core.ViewModels.Items
{
    public class CreateItemViewModel
    {
        public int CategoryId { get; set; }
    }
}
