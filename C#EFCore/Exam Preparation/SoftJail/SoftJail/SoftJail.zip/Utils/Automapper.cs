﻿using AutoMapper;

namespace SoftJail.Utils
{
    public static class Automapper
    {              

        public static IMapper InitializeAutomaper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<SoftJailProfile>();
            });

            var mapper = config.CreateMapper();
            return mapper;
        }
    }
}
