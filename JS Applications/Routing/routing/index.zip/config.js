var firebaseConfig = {
    apiKey: "AIzaSyB1GWETwJz9qofkzxI4p80a6VTaMaLPzTw",
    authDomain: "exercise-remote-database.firebaseapp.com",
    databaseURL: "https://exercise-remote-database.firebaseio.com",
    projectId: "exercise-remote-database",
    storageBucket: "exercise-remote-database.appspot.com",
    messagingSenderId: "900669439272",
    appId: "1:900669439272:web:2a90949de664256f5f241d"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
