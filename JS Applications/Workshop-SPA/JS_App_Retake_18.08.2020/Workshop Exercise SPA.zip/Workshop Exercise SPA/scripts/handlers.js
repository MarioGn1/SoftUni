function clickedDiv(id) {     
   id.lastElementChild.click();
}