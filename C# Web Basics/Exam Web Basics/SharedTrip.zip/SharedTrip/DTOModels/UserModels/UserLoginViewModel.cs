﻿namespace SharedTrip.DTOModels.UserModels
{
    public class UserLoginViewModel
    {
        public string Username { get; init; }
        public string Password { get; init; }
    }
}
