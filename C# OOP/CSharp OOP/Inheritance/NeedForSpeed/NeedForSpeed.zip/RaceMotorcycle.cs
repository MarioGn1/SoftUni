﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    class RaceMotorcycle : Motorcycle
    {
        public RaceMotorcycle(int horsePower, double fuel) : base(horsePower, fuel)
        {
            this.DefaultFuelConsumption = 8;
        }
        public override void Drive(double kilometers)
        {
            this.FuelConsumption = kilometers * this.DefaultFuelConsumption;
            this.Fuel -= FuelConsumption;
        }

        public double DefaultFuelConsumption { get; set; }
    }
}
