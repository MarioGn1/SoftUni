﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
}
