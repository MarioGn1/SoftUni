﻿

namespace WildFarm.IO
{
    public interface IWriter
    {
        void WriteLine(string text);

        void Write(string text);
    }
}
