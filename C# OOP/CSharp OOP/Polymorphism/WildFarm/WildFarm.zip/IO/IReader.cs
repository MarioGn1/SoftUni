﻿

namespace WildFarm.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
