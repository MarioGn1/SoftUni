﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Food
{
    class Fruit : Food
    {
        public Fruit(int qty) : base(qty)
        {
        }
    }
}
