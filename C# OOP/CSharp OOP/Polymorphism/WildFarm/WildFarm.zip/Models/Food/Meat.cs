﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Food
{
    class Meat : Food
    {
        public Meat(int qty) : base(qty)
        {
        }
    }
}
