﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Enumerators
{
    public enum FoodType
    {
        Vegetable = 1,
        Fruit = 2,
        Meat = 3,
        Seeds = 4,
    }
}
