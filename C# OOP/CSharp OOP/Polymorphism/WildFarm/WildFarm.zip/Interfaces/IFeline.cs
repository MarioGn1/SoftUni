﻿

namespace WildFarm.Interfaces
{
    public interface IFeline : IMammal
    {
        string Breed { get; }
    }
}
