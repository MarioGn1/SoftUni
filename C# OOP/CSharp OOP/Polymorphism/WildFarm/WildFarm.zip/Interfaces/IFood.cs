﻿

namespace WildFarm.Interfaces
{
    public interface IFood
    {
        int Qty { get; }
    }
}
