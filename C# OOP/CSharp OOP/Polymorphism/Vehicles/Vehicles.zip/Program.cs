﻿using Microsoft.VisualBasic;
using System;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputCar = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] inputTruck = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            int n = int.Parse(Console.ReadLine());

            Vehicle car = new Car(double.Parse(inputCar[1]), double.Parse(inputCar[2]));
            Vehicle truck = new Truck(double.Parse(inputTruck[1]), double.Parse(inputTruck[2]));

            for (int i = 0; i < n; i++)
            {
                string[] curCommand = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string action = curCommand[0];
                string vehicleType = curCommand[1];
                double actionParameter = double.Parse(curCommand[2]);
                switch (action)
                {
                    case "Drive":
                        if (vehicleType == "Car")
                        {
                            Console.WriteLine((car as Car).Drive(actionParameter));
                        }
                        else if (vehicleType == "Truck")
                        {
                            Console.WriteLine((truck as Truck).Drive(actionParameter));
                        }

                        break;
                    case "Refuel":
                        if (vehicleType == "Car")
                        {
                            (car as Car).Refuel(actionParameter);
                        }
                        else if (vehicleType == "Truck")
                        {
                            (truck as Truck).Refuel(actionParameter);
                        }

                        break;
                    default:
                        throw new ArgumentException("Invalid action!");
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }
    }
}
