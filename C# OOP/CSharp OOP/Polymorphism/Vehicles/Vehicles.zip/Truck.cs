﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    class Truck : Vehicle
    {
        private const double AC_RISE_CONSUMPTION = 1.6;
        public Truck(double fuelQty, double fuelConsumption) : base(fuelQty, fuelConsumption + AC_RISE_CONSUMPTION)
        {
        }
                
        public override void Refuel(double liters)
        {
            this.FuelQty += liters * 0.95; 
        }
    }
}
