﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        public Vehicle(double fuelQty, double fuelConsumption)
        {
            this.FuelQty = fuelQty;
            this.FuelConsumption = fuelConsumption;
        }

        public string Drive(double distance)
        {
            double requiredFuel = distance * this.FuelConsumption;
            if (requiredFuel <= FuelQty)
            {
                FuelQty -= requiredFuel;
                return $"{this.GetType().Name} travelled {distance} km";
            }
            return $"{this.GetType().Name} needs refueling";
        }

        public abstract void Refuel(double liters);


        protected double FuelQty { get; set; }

        protected double FuelConsumption { get; set; }


        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQty:F2}";
        }

    }
}
