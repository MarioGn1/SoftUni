﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        private const double AC_RISE_CONSUMPTION = 0.9;
        public Car(double fuelQty, double fuelConsumption) : base(fuelQty, fuelConsumption + AC_RISE_CONSUMPTION)
        {
        }
        
        public override void Refuel(double liters)
        {
            this.FuelQty += liters;
        }
    }
}
