﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
