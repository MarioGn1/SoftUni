﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IInhabitable> inhabitants = new List<IInhabitable>();

            string command;
            while ((command = Console.ReadLine()) != "End")
            {

                string[] curInhabitant = command.Split();
                IInhabitable inhabitant;
                if (curInhabitant.Length == 3)
                {
                    inhabitant = new Citizens(curInhabitant[0],
                        int.Parse(curInhabitant[1]),
                        (curInhabitant[2]));
                }
                else
                {
                    inhabitant = new Robot(curInhabitant[0],
                        (curInhabitant[1]));
                    
                }
                inhabitants.Add(inhabitant);
            }

            string criteria = Console.ReadLine();
            
            inhabitants.Where(el => el.Id.EndsWith(criteria))
                .ToList()
                .ForEach(el => Console.WriteLine(el.Id));

        }
    }
}
