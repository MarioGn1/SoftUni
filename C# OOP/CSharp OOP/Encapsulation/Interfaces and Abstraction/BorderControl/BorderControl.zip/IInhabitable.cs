﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IInhabitable
    {
        public string Name { get; }
        public string Id { get; }
    }
}
