﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IInhabitable> inhabitants = new List<IInhabitable>();
            

            string command;
            while ((command = Console.ReadLine()) != "End")
            {

                string[] curInhabitant = command.Split();
                IInhabitable inhabitant = null;
                if (curInhabitant[0] == "Citizen")
                {
                    inhabitant = new Citizens(curInhabitant[1],
                        int.Parse(curInhabitant[2]),
                        curInhabitant[3],
                        curInhabitant[4]);
                    
                }
                else if (curInhabitant[0] == "Robot")
                {
                    inhabitant = new Robot(curInhabitant[1],
                        (curInhabitant[2]));
                    
                }
                else if(curInhabitant[0] == "Pet")
                {
                    inhabitant = new Pet(curInhabitant[1],
                        (curInhabitant[2]));
                    
                }
             
                inhabitants.Add(inhabitant);

            }

            string criteria = Console.ReadLine();

            inhabitants.Where(el => el.Birthday != null)
                .ToList()
                .Where(el => el.Birthday.EndsWith(criteria))
                .ToList()
                .ForEach(el => Console.WriteLine(el.Birthday));

        }
    }
}
