﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Text;

namespace DateModifier
{
    class DateModifier
    {
        private List<DateTime> dates;

        public List<DateTime> Dates
        {
            get => dates;
            set => dates = value;
        }
        //private int year;
        //private int difference;

        //private DateTime date;

        //public DateTime Date
        //{
        //    get { return date; }
        //    set { date = value; }
        //}

        //public int Year
        //{
        //    get { return year; }
        //    set { year = value; }
        //}
        //private int month;

        //public int Month
        //{
        //    get { return month; }
        //    set { month = value; }
        //}

        //private int day;

        //public int Day
        //{
        //    get { return day; }
        //    set { day = value; }
        //}

        //public DateModifier(int year, int month, int day)
        //{
        //    this.Year = year;
        //    this.Month = month;
        //    this.Day = day;
        //}
        public DateModifier()
        {
            this.Dates = new List<DateTime>();
        }
        public void AddDate(DateTime date)
        {
            Dates.Add(date);
        }

        public int GetDifferenceOfTwoDays()
        {
            TimeSpan difference = Dates[1] - Dates[0];
            
            return int.Parse(difference.Days.ToString());
        }
    }
}
