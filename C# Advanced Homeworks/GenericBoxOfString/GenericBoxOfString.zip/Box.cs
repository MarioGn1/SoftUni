﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericBoxOfString
{
    class Box
    {
        private List<object> colection;

        
        public Box()
        {
            this.colection = new List<object>();
        }

        public List<object> AddObject(object element)
        {
            
            colection.Add(element);

            return colection;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in colection)
            {
                sb.AppendLine($"{item.GetType()}: {item}");
            }

            return sb.ToString();
        }
    }
}
