﻿using System;
using System.Runtime.InteropServices;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var colection = new Box();

            for (int i = 0; i < n; i++)
            {
                object curElement = Console.ReadLine();
                colection.AddObject(curElement);
            }

            Console.WriteLine(colection);
        }
    }
}
