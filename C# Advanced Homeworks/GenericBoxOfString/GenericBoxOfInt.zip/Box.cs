﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericBoxOfString
{
    class Box
    {
        private List<dynamic> colection;
        private object obj;
        
        public Box()
        {
            this.colection = new List<dynamic>();
        }

        public List<dynamic> AddObject(dynamic element)
        {
            
            colection.Add(element);

            return colection;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in colection)
            {
                
                sb.AppendLine($"{item.GetType()}: {item}");
            }

            return sb.ToString();
        }
    }
}
