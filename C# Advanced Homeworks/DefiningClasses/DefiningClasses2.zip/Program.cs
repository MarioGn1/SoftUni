﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            Person persontwo = new Person(10);
            Person personthree = new Person("Mario", 20);

            Console.WriteLine($"{person.Name} {person.Age}");
            Console.WriteLine($"{persontwo.Name} {persontwo.Age}");
            Console.WriteLine($"{personthree.Name} {personthree.Age}");
        }
    }
}
